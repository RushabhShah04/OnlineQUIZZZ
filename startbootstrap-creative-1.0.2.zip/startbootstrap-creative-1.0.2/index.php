<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>It's Quiz time</title>

    <!-- Bootstrap Core CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">

    <!-- Custom Fonts -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css" type="text/css">

    <!-- Plugin CSS -->
    <link rel="stylesheet" href="css/animate.min.css" type="text/css">

    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/creative.css" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body id="page-top">

    <nav id="mainNav" class="navbar navbar-default navbar-fixed-top">
        <div class="container-fluid">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand page-scroll" href="#page-top">Start Quiz</a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li>
                        <a class="page-scroll" href="#about">Login</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="#services">Start Now</a>
                    </li>
                    
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>

    <header>
        <div class="header-content">
            <div class="header-content-inner">
                <h1>Let's Try Your Knowledge</h1>
                <hr>
                <p>Start Quiz Now And Check Your Brains that working or Not.</p>
               
    <?php 
if(isset($_SESSION['username'])==1)
{ 
?>
        <form name="fr1" method="post" style="display: inline;"><button type="submit" name="logout" class="btn btn-lg btn-danger" >Log Out</button></form>
        
<?php 
} 
?>

<?php 
if(!isset($_SESSION['username'])) 
{
?>

        <button data-toggle="collapse"  class="btn btn-lg btn-success"  data-target="#demo">Log in</button>
        <button type="button" name="sigup" class="btn btn-lg btn-warning">Sign Up</button>
<?php
 } 

?>

<div id="demo" class="collapse">
<form name="frm_log" action="" method="POST">
        <table border="1" class="table" style="border-spacing:1px; border-style: dashed;" >
            <tr>
                <td><font size="3">Username</td>
                <td><font color="black"><input type="text" name="txt_uname"></input></font></td>
            </tr>
            
            <tr>
                <td><font size="3"> Password</td>
                <td><font color="black"><input type="password" name="txt_pass"></input></font></td>
            </tr>

            <tr>
                <t><button type="submit" name="login" class="btn btn-large btn-block btn-danger">Log in Now</button></t>
            </tr>
        </table>

</form>
</div>
</div>

<?php

if(isset($_POST['logout']))
{

    if(isset($_SESSION['username']))
    {
        unset($_SESSION['username']);
        //echo "unset";
        header("Refresh:0");
    }
    else
    {
        //echo "not set yet";
    }

}

if(isset($_POST['login']))
{
    #echo "Login Presses";
    $uname=$_POST['txt_uname'];
    $pass=$_POST['txt_pass'];

if($uname=='admin123')
    {if($pass=='pass123')
{
    header('location:admin1.php');
}
}
    
include('connection.php');
    $q=mysqli_query($con,"select * from regi");

    while ($row=mysqli_fetch_array($q)) 
    {
        if($row[1]==$uname)
        {
            if($row[2]==$pass)
            {
                //echo "Success";
                //header("location:index.php");
                $reg_id=$row[0];

                $_SESSION['username']=$uname;

                 
                
                /*$s=$_SESSION['log'];
                echo $s;*/
                //echo "session set ";
                #echo "user match" ;
                header('location:user1.php');
            }
            else
            {   
                ?>
                <div class="progress-bar progress-bar-danger animated rollIn animated-duration-1s animated-delay-2200ms" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width: 100%;height: 5%;">
                                                       <font size="4" face="cambria" style="padding-top: 5px;"> Incorrect Password</font>
                                                    </div>
            
                                                    <?php
                //echo "Password incorrect";
            }
        }
        else
        {
            ?>
            
            <div class="progress-bar progress-bar-danger animated rollIn animated-duration-1s animated-delay-2200ms" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="10" style="width: 100%; height: 5%;">
                                                        <font size="4" face="cambria" style="padding-top: 5px;"> Incorrect Username</font>
                                                    </div>
            <?php
            #echo "Login incorrect";
        }
    }
}
?>



<div class="col-xm-2 col-sm-6 col-md-6 col-lg-9 col-xl-9" id="x" style="float: left;">
<style type="text/css">
    #x{
    font-size:50px;

     font-family: sarif;

    animation:alternate-reverse;

    }<b>
</style>

</b>
            </div>
        </div>
    </header>

    
    <section id="contact">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-lg-offset-2 text-center">
                    <h2 class="section-heading">Let's Get In Touch!</h2>
                    <hr class="primary">
                    <p>Ready to start your next project with us? That's great! Give us a call or send us an email and we will get back to you as soon as possible!</p>
                </div>
                <div class="col-lg-4 col-lg-offset-2 text-center">
                    <i class="fa fa-phone fa-3x wow bounceIn"></i>
                    <p>123-456-6789</p>
                </div>
                <div class="col-lg-4 text-center">
                    <i class="fa fa-envelope-o fa-3x wow bounceIn" data-wow-delay=".1s"></i>
                    <p><a href="mailto:your-email@your-domain.com">feedback@startbootstrap.com</a></p>
                </div>
            </div>
        </div>
    </section>

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="js/jquery.easing.min.js"></script>
    <script src="js/jquery.fittext.js"></script>
    <script src="js/wow.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="js/creative.js"></script>

</body>

</html>
