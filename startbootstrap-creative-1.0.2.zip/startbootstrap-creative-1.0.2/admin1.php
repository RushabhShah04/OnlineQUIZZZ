<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>It's Quiz time</title>

    <!-- Bootstrap Core CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">

    <!-- Custom Fonts -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css" type="text/css">

    <!-- Plugin CSS -->
    <link rel="stylesheet" href="css/animate.min.css" type="text/css">

    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/creative.css" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body id="page-top">

    <nav id="mainNav" class="navbar navbar-default navbar-fixed-top">
        <div class="container-fluid">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand page-scroll" href="#page-top">Start Quiz</a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li>
                        <a class="page-scroll" href="#about">Home</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="#services">Create Assessment </a>
                    </li>
                    <li>
                        <a class="page-scroll" href="#about">View Results</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="logout.php">
                        	logout

                            <?php session_unset('username'); ?>
                        </a>
                    </li>
                    
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>

    <header>
        <div class="header-content">
            <div class="header-content-inner">
                <h1>Welcome ,Admin</h1>
                <hr>
                <p>Create Quiz Now And Test Brains of others working or Not.</p>
               
    

<div class="col-xm-2 col-sm-6 col-md-6 col-lg-9 col-xl-9" id="x" style="float: left;">
<style type="text/css">
    #x{
    font-size:50px;

     font-family: sarif;

    animation:alternate-reverse;

    }<b>
</style>

</b>
            </div>
        </div>
    </header>

 <section id="Main">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-lg-offset-2 text-center">
                    <h2 class="section-heading">Let's Start Adding Questions!</h2>
                    <hr class="primary">
                    <p></p>
                </div>
                <div class="col-lg-12 col-lg-offset-0 text-center">
                	<form name="frm1" method="POST">
                		<br>
                		<input type="text" name=val placeholder="Enter No Of Questions"></input>
                		<button type="submit" class="btn btn-success" name=sub1 ="Let's Add">Let's Add</button>


                	</form>
                    <?php if(isset($_GET['p']))
                    {
                        ?><div class="alert alert-success">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <strong>QUESTIONS ADDED</strong> 
                        </div><?php
                        } ?>
                </div>
<?php $val=0; ?>
				<div class="col-lg-12 col-lg-offset-0 text-center">

<?php
if(isset($_POST['sub1']))
{
    $no = $_POST['val'];
    ?> 
    <form action="temp.php" name=frm1 method="POST" role="form">
     <?php
    for ($i=1; $i <= $no ; $i++) { 
    
    
    ?>
                
               <input type="text"   name="qu[<?php echo $i; ?>]" class="form-control" placeholder="Enter Your Question <?php echo $i; ?>"> 
               <input type='text'  name="opt1[<?php echo $i; ?>]" placeholder='Enter Option1'>
               <input type='text'  name="opt2[<?php echo $i; ?>]" placeholder='Enter Option2'>
               <input type='text'  name="opt3[<?php echo $i; ?>]" placeholder='Enter Option3'>
               Answer<input type='text'  name="opt4[<?php echo $i; ?>]" placeholder='Enter Option4'><br>
               <div class="alert alert-success">
                        
                        <strong>Answer !</strong>
                         <input type='text'  name="ans[<?php echo $i; ?>]" placeholder='Enter Answer'>
                    </div>
               <br>
          
       
    <?php
   }
   ?> <br><input type="hidden" name="valx" value="<?php echo $no; ?>"></input>
   <button name=subz type="submit" class="btn btn-primary">Submit Questions </button>
       </form> 
        <?php
}
?>

				<!--<form action="#" method="POST" role="form">
				<?php
				 /*	if(isset($_POST['sub1']))
					{
						
                        $val=$_POST['val'];
						for($i=1;$i<=$val;$i++)
						{
							
							echo "";

					echo '<div class="form-group">';
					echo "<label for=''>Question No $i</label>";
					echo "<input type='text' class='form-control'  name='$i' id='q1' placeholder='Enter Question$i'>";
					echo "<input type='text'  name='a1$i' placeholder='Enter Option1'>";
					echo "<input type='text'  name='a2$i' placeholder='Enter Option2'>";
					echo "<input type='text'  name='a3$i' placeholder='Enter Option3'>";
					echo "<input type='text'  name='a4$i' placeholder='Enter Option4'>";
					
					echo '</div>';
					

						}
						?><button type="submit" class="btn btn-lg btn-success" name=subfinal >Create Assessment </button>
				</form>
				<?php	}
				?>

                <?php
                if(isset($_POST['subfinal']))
                {
                    /*$ques[0]=0;
                    
                    for ($i=1; $i < $val; $i++) { 
                            $ques[$i]=array($_POST[$i]);
                            
                    }
                      
                      foreach ($ques as $key => $value) {
                          echo $key;
                          
                      }
                
*/
                    
                    
                    ?><div class="alert alert-success">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                        <strong>Submitted !</strong> Your Questions Are Submitted Correctly ...
                    </div><?php
                
                ?>*/
                --> 
				
				</div>
                
            </div>
        </div>
    </section>
    
    <section id="contact">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-lg-offset-2 text-center">
                    <h2 class="section-heading">Let's Get In Touch!</h2>
                    <hr class="primary">
                    <p>Ready to start your next project with us? That's great! Give us a call or send us an email and we will get back to you as soon as possible!</p>
                </div>
                <div class="col-lg-4 col-lg-offset-2 text-center">
                    <i class="fa fa-phone fa-3x wow bounceIn"></i>
                    <p>123-456-6789</p>
                </div>
                <div class="col-lg-4 text-center">
                    <i class="fa fa-envelope-o fa-3x wow bounceIn" data-wow-delay=".1s"></i>
                    <p><a href="mailto:your-email@your-domain.com">feedback@startbootstrap.com</a></p>
                </div>
            </div>
        </div>
    </section>

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="js/jquery.easing.min.js"></script>
    <script src="js/jquery.fittext.js"></script>
    <script src="js/wow.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="js/creative.js"></script>

</body>

</html>
