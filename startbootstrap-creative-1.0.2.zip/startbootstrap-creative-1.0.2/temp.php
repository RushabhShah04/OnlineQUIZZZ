<?php

          if(isset($_POST['subz']))
          {
            $n=$_POST['valx'];
            
            echo $n;
            

            for ($i=1; $i <= $n ; $i++) { 
             $v= $_POST['qu'][$i];
               $v1= $_POST['opt1'][$i];
             $v2= $_POST['opt2'][$i];
              $v3= $_POST['opt3'][$i];
              $v4= $_POST['opt4'][$i];
              $v5= $_POST['ans'][$i];

              $qu=
              "INSERT INTO ques(Ques_id, ques, opt1, opt2, opt3, opt4,Ans) VALUES 
              ('','$v','$v1','$v2','$v3','$v4' ,'$v5')";
$conn=mysqli_connect("localhost","root","","quiz");
echo $qu;
              mysqli_query($conn,$qu);
            }
          }

          header("location:admin1.php"); 
   
?>