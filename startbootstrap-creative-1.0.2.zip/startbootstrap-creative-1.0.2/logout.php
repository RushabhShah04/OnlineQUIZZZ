<?php
session_unset('username');

header("location:index.php");
?>